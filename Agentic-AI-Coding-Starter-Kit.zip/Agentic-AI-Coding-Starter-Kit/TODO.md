# TODO

- Create an `AGENTS.md` that is shared by all contributors and treat it as the living source of truth for both biological and digital teammates.
- Organize documentation, guidelines, and standards so the repo stays ready for future collaboration patterns.
- Define core personas (Architecture, Development, Bugfixing, Design, Refactoring, …) to capture the project’s key viewpoints.
- Schedule regular cleanups (e.g., via the Refactoring persona) to keep the repository lean—AI quality erodes when context becomes noisy or poorly structured.
