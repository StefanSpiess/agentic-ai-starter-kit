# Technology Stack

- Frontend: React, TypeScript, Tailwind CSS
- Backend: Node.js, Express, PostgreSQL
- AI/Automation: GitHub Copilot, Agent OS
- CI/CD: GitHub Actions
