# Product Roadmap

## Q4 2025
- Integrate Agent OS 3-layer context system
- Launch spec-driven development workflow
- Add support for custom standards and profiles

## Q1 2026
- Expand AI agent capabilities
- Improve onboarding and documentation
