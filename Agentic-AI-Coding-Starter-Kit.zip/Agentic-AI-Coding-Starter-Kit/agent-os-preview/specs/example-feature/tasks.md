# Task Breakdown: Example Feature

## Frontend
- [ ] Add button to dashboard
- [ ] Display real-time results

## Backend
- [ ] Implement API endpoint
- [ ] Integrate logging

## Testing
- [ ] Write unit and integration tests
