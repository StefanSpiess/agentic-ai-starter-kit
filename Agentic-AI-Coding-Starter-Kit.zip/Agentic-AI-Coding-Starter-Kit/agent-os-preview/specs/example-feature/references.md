# References for Example Feature

- [Similar feature in another repo](https://github.com/example/repo)
- [Design mockup](../assets/mockup.png)
- [API documentation](../../standards/backend/README.md)
